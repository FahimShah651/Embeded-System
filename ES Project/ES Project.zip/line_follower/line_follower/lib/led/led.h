/*
 * led.h
 *
 * Created: 5/29/2012 5:46:18 PM
 *  Author: Avinash Gupta
 */ 


#ifndef LED_H_
#define LED_H_

void LEDInit();

void LEDOff(uint8_t id);
void LEDOn(uint8_t id);




#endif /* LED_H_ */